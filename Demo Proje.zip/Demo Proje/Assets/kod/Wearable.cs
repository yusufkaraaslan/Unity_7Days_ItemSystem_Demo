﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System;

public class Wearable : item {

	private bool inuse = false;
	public bool Inuse{
		get{return inuse;}
		set{inuse = value;}
	}

	private Dictionary<stat,int> Power = new Dictionary<stat, int>();
	public void setPower(stat pow , int val){
		if (val > 0) {
			Power [pow] = val;
		} else if (val == 0) {
			Power.Remove (pow);
		}
	}
	public int getPower(stat pow){
		if (Power.ContainsKey (pow)) {
			return Power [pow];
		} else
			return 0;
	}

	//--------------------------------------------------------------

	public string Saveitem(){
		string StrTmp = base.save () + "/";

		foreach (stat x in Power.Keys) {
			StrTmp = StrTmp + x + "-" + Power [x] + "-";
		}

		StrTmp += "/";
		StrTmp += inuse;
		StrTmp += "/";
		return StrTmp;
	}
		
	public void Loaditem(string old){
		string[] part1 = old.Split ('/');
		if (part1.Length == 4) {
			base.Loaditem (part1 [0]);
			string[] part2 = part1 [1].Split ('-');

			for (int i = 0; i + 1 < part2.Length; i += 2) {
				Power [(stat)Enum.Parse (typeof(stat), part2 [i])] = Convert.ToInt32 (part2 [i + 1]);
			}

			inuse = (part1[2] == "true") ? true : false;
		}

	}

	public void Upgrade(){
		if (Update) {
			++Level;
			foreach (stat x in System.Enum.GetValues(typeof(stat))) {
				if (Power.ContainsKey (x)) {
					Power [x] = Power [x] + UnityEngine.Random.Range (3, 10);
				}
			}
		}
	}

	public string inspect(){
		string listline = base.inspect ();

		listline += "--- Stats ---\n";
		foreach (stat x in Power.Keys) {
			listline += x + " : "+Power[x]+"\n";
		}

		return listline;
	}

	public Wearable CloneItm(){
		Wearable tmp = new Wearable ();
		tmp.Loaditem (Saveitem ());
		return tmp;	
	}

}
