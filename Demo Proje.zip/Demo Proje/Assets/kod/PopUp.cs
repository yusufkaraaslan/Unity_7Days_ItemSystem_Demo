﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.EventSystems;

public class PopUp : MonoBehaviour, IPointerClickHandler {

	HidePopup closeText;
	Text PopText;
	public static int code;
	
	#region IPointerClickHandler implementation
	public void OnPointerClick (PointerEventData eventData)
	{
		code = GetComponentInParent<slot> ().slotCode;
		if (code < 15) {
			PopText.text = characterinfo.wearableinventory [code].inspect ();
		} else {
			switch (code) {
			case 15:
				PopText.text = characterinfo.inUse [itemtype.UpArmor].inspect ();
				break;
			case 16:
				PopText.text = characterinfo.inUse [itemtype.MiddleArmor].inspect ();
				break;
			case 17:
				PopText.text = characterinfo.inUse [itemtype.DownArmor].inspect ();
				break;
			case 18:
				PopText.text = characterinfo.inUse [itemtype.Wepon].inspect ();
				break;
			}
		}

		closeText.ClosePopup ();
	}
	#endregion

	// Use this for initialization
	void Start () {
		PopText = GameObject.FindGameObjectWithTag ("PopText").GetComponent<Text>();
		closeText = GameObject.FindGameObjectWithTag ("PopText").GetComponent<HidePopup> ();
	}

}
