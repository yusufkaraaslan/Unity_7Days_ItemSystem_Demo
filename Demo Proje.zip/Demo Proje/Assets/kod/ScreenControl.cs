﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.EventSystems;

public class ScreenControl : MonoBehaviour , IHasChanged {
	#region IHasChanged implementation

	public void HasChanged ()
	{
		GameObject.FindGameObjectWithTag ("UIManeger").GetComponent<DrawItem> ().drowItem ();
	}

	#endregion




}

namespace UnityEngine.EventSystems{
	public interface IHasChanged : IEventSystemHandler{
		void HasChanged();
	}
}
