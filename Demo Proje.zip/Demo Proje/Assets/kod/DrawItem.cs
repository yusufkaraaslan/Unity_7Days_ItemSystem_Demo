﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class DrawItem : MonoBehaviour {
	
	public GameObject[] inventory = new GameObject[15];
	public Dictionary<itemtype,GameObject> inUse = new Dictionary<itemtype, GameObject>() ;
	public GameObject[] inUseSlot = new GameObject[4];

	public GameObject[] prefabImg = new GameObject[4];
	Dictionary<itemtype,GameObject> prefab = new Dictionary<itemtype, GameObject>();

	public static bool refresh = false;

	void Start(){
		prefab.Add (itemtype.UpArmor,
			prefabImg [0]);
		prefab.Add (itemtype.MiddleArmor,
			prefabImg [1]);
		prefab.Add (itemtype.DownArmor,
			prefabImg [2]);
		prefab.Add (itemtype.Wepon,
			prefabImg [3]);
		inUse.Add (itemtype.Wepon, inUseSlot[0]);
		inUse.Add (itemtype.UpArmor, inUseSlot[1]);
		inUse.Add (itemtype.MiddleArmor, inUseSlot[2]);
		inUse.Add (itemtype.DownArmor, inUseSlot[3]);
	}

	public void drowItem(){
		// v2 ----------------------------------------------------------------

		if (characterinfo.inUse == null) {
			if (inUse [itemtype.Wepon].transform.childCount > 0) {
				Destroy (inUse [itemtype.Wepon].transform.GetChild (0).gameObject);
			}
			if (inUse [itemtype.UpArmor].transform.childCount > 0) {
				Destroy (inUse [itemtype.UpArmor].transform.GetChild (0).gameObject);
			}
			if (inUse [itemtype.MiddleArmor].transform.childCount > 0) {
				Destroy (inUse [itemtype.MiddleArmor].transform.GetChild (0).gameObject);
			}
			if (inUse [itemtype.DownArmor].transform.childCount > 0) {
				Destroy (inUse [itemtype.DownArmor].transform.GetChild (0).gameObject);
			}
		} else {
			foreach (itemtype x in System.Enum.GetValues(typeof(itemtype))) {
				if (characterinfo.inUse.ContainsKey (x)) {
					if (inUse.ContainsKey (x)) {
						if (inUse [x].transform.childCount > 0) {
							Destroy (inUse [x].transform.GetChild(0).gameObject);
						}
					}
					Instantiate (prefab [x], inUse [x].transform);
					
				} else {
					if (inUse.ContainsKey (x)) {
						if (inUse [x].transform.childCount > 0) {
							Destroy (inUse [x].transform.GetChild(0).gameObject);
						}
					}
				}
			}
		}


		for (int i = 0; i < characterinfo.SLOTNUM; ++i) {
			if (characterinfo.wearableinventory [i] != null) {
				if (inventory [i].transform.childCount > 0) {
					Destroy (inventory [i].transform.GetChild(0).gameObject);
				}
				Instantiate (prefab [characterinfo.wearableinventory [i].Type], inventory [i].transform);
			}else {
				if (inventory [i].transform.childCount > 0) {
					Destroy (inventory [i].transform.GetChild(0).gameObject);
				}
			}
		}

	}
}
