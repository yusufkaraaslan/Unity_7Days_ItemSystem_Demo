﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class fillDropdown : MonoBehaviour {

	Dropdown ops ;
	public datatype mod;
	List<string> itemtype_name = new List<string>(System.Enum.GetNames(typeof(itemtype)));
	List<string> disenchant_name = new List<string>(System.Enum.GetNames(typeof(disenchant)));
	List<string> rarity_name = new List<string>(System.Enum.GetNames(typeof(rarity)));
	List<string> stat_name = new List<string>(System.Enum.GetNames(typeof(stat)));

	// Use this for initialization
	void Start () {
		ops = GetComponent<Dropdown> ();
		fill ();
	}
	
	void fill(){
		switch (mod) {
		case datatype.itemtype:
			ops.ClearOptions ();
			ops.AddOptions (itemtype_name);
			break;
		case datatype.disenchant:
			ops.ClearOptions ();
			ops.AddOptions (disenchant_name);
			break;
		case datatype.rarity:
			ops.ClearOptions ();
			ops.AddOptions (rarity_name);
			break;
		case datatype.stat:
			ops.ClearOptions ();
			ops.AddOptions (stat_name);
			break;
		}
	}
}
