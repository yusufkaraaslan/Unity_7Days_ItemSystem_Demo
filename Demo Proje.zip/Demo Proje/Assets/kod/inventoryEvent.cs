﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public static class inventoryEvent {

	public static int fromCode = -3 , toCode = -3 ;

	public static bool moveIt(){
		// inventory ->
		if(fromCode >= 0 && fromCode <=14 ){

			// -> inventory-----------------------------------------------------v
			if(toCode >= 0 && toCode <= 14){
				characterinfo.SwitchPos (fromCode, toCode);
				toCode = -3;
				return true;
			}

			// -> inuse---------------------------------------------------------v
			if(toCode > 14){
				bool resin = false;
				switch (toCode) {
				case 15:
					resin =  characterinfo.Wearitem (fromCode, itemtype.UpArmor);
					break;
				case 16:
					resin =  characterinfo.Wearitem (fromCode, itemtype.MiddleArmor);
					break;
				case 17:
					resin =  characterinfo.Wearitem (fromCode, itemtype.DownArmor);
					break;
				case 18:
					resin = characterinfo.Wearitem (fromCode, itemtype.Wepon);
					break;
				}
				toCode = -3;
				return resin;
			}

			// -> upt.----------------------------------------------------------v
			if(toCode == -1){
				toCode = -3;
				characterinfo.wearableinventory [fromCode].Upgrade ();
				return true;
			}

			// -> destroy-------------------------------------------------------v
			if(toCode == -2){
				characterinfo.destroy (fromCode);
				return true;// TEMP
			}
			
		}

		//////////////////////////////////////////////////////////////////////////

		// inuse ->
		if(fromCode > 14){

			// -> inventory------------------------------------------------------v
			if(toCode >= 0 && toCode <= 14){
				bool res = false;
				switch (fromCode) {
				case 15:
					res =  characterinfo.TakeOut (itemtype.UpArmor, toCode);
					break;
				case 16:
					res = characterinfo.TakeOut (itemtype.MiddleArmor, toCode);
					break;
				case 17:
					res = characterinfo.TakeOut (itemtype.DownArmor, toCode);
					break;
				case 18:
					res = characterinfo.TakeOut (itemtype.Wepon, toCode);
					break;
				}
				toCode = -3;
				return res;
			}

			// -> inuse-----------------------------------------------------------v
			if(toCode > 14){
				return false;
			}

			// -> upt.-------------------------------------------------------------v
			if(toCode == -1){
				toCode = -3;
				switch (fromCode) {
				case 15:
					characterinfo.inUse [itemtype.UpArmor].Upgrade ();
					break;
				case 16:
					characterinfo.inUse [itemtype.MiddleArmor].Upgrade ();
					break;
				case 17:
					characterinfo.inUse [itemtype.DownArmor].Upgrade ();
					break;
				case 18:
					characterinfo.inUse [itemtype.Wepon].Upgrade ();
					break;
				}
				characterinfo.CalculateStat ();
				return true;
			}

			// -> destroy----------------------------------------------------------v
			if(toCode == -2){
				characterinfo.destroy (fromCode);
				return true;// TEMP
			}
			
		}
		//////////////////////////////////////////////////////////////////////////
		return false;
	}
	 
}
