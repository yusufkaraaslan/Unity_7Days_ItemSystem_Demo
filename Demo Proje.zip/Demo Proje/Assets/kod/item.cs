﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System;

public class item {


	private Sprite image;
	bool writeimg = true;
	public Sprite Image{
		get{ return image;}
		set{ 
			if (writeimg) {
				image = value;
			}
		}
	}

	string name;
	bool writeNam = true;
	public string Name{
		get{return name;}
		set{ 
			if (writeNam) {
				name = value;
			}
		}
	}

	private itemtype type;
	bool writetyp = true;
	public itemtype Type{
		get{return type;}
		set{
			if (writetyp) {
				type = value;
			}
		}
	}

	private int level = 1;
	public int Level{
		get{return level;}
		set{level = value;}
	}

	private disenchant disench;
	bool writedis = true;
	public disenchant Disench{
		get{return disench;}
		set{
			if (writedis) {
				disench = value;
			}
		}
	}

	private rarity rank;
	bool writeran = true;
	public rarity Rank{
		get{return rank;}
		set{
			if (writeran) {
				rank = value;
			}
		}
	}

	private bool update;
	bool writeUpd =true;
	public bool Update{
		get{return update;}
		set{
			if(writeUpd){
				update = value;
			}
		}
	}


	//-------------------------------------------------

	public void Lockitem(){
		writedis = false;
		writeNam = false;
		writeran = false;
		writetyp = false;
		writeUpd = false;
		writeimg = false;
	}

	public void Destroyitem(){
		if (disench != disenchant.CantDestroy) {
			characterinfo.rawmaterial [disench] += 3 * level;
		}
	}

	public string save(){
		return name + "," + type + "," + level + "," + disench + "," + rank + "," + update ;
	}

	public string inspect(){
		string res = "";
		res += "Name : " + name + "\n";
		res +=  "Type : " + type + "\n";
		res += "rarity : " + rank + "\n";
		res += "Disenchant : " + disench + "\n";
		res += "Level : " + level + "\n";
		res += "can it upgrade : " + update + "\n";

		return res;
	}

	public void Loaditem(string old){
		string[] tmp = old.Split (',');
		if (tmp.Length == 6) {
			name = tmp [0];
			writeNam = false;
			type = (itemtype)Enum.Parse (typeof(itemtype), tmp [1]);
			writetyp = false;
			level = Convert.ToInt32 (tmp [2]);
			disench = (disenchant)Enum.Parse (typeof(disenchant), tmp [3]);
			writedis = false;
			rank = (rarity)Enum.Parse (typeof(rarity), tmp [4]);
			writeran = false;
			update = (tmp [5] == "True") ? true : false;
			writeUpd = false;
		} else {
			Debug.Log("Eror to load item.");
		}
	}

}
