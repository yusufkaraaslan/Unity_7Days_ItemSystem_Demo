﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public enum stat{Helath,Mana,Damage,Defense,Vitallity,Resistance};
public enum itemtype{Wepon,UpArmor,MiddleArmor,DownArmor};
public enum disenchant{CantDestroy,Sand,iron};
public enum rarity{Common,Rare,Epic};
public enum datatype{stat,itemtype,disenchant,rarity,};

public class DataType {


}
