﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public static class characterinfo {

	public const int SLOTNUM = 15;

	public static string Name = "YuszYusz";
	public static Dictionary<itemtype,Wearable> inUse = new Dictionary<itemtype, Wearable>() ;
	public static Dictionary<stat,int> Power = new Dictionary<stat, int>();
	public static Wearable[] wearableinventory = new Wearable[SLOTNUM];
	public static Dictionary<disenchant,int> rawmaterial;
		
	public static void Addinventory(Wearable itm){
		bool keep = true;
		for(int i = 0 ; i < SLOTNUM && keep ; ++i){
			if (wearableinventory [i] == null) {
				wearableinventory [i] = itm;
				keep = false;
			}
		}
	}

	public static void SwitchPos(int FromPos,int ToPos){
		if (FromPos < SLOTNUM && ToPos < SLOTNUM) {
			Wearable tmp = wearableinventory [ToPos];
			wearableinventory [ToPos] = wearableinventory [FromPos];
			wearableinventory [FromPos] = tmp;
		}
	}

	public static bool Wearitem(int itmSlt , itemtype slt){
		if (wearableinventory[itmSlt].Type == slt) {
			wear (itmSlt, slt);
			wearableinventory [itmSlt] = null;
			CalculateStat ();
			return true;
		}
		return false;
	}

	static void wear(int itm, itemtype slt){
		Wearable old_itm = null;
		if (inUse.ContainsKey (slt)) {
			old_itm = inUse [slt];
		}
		inUse [slt] = wearableinventory [itm];
		wearableinventory [itm] = old_itm;
	}

	public static void CalculateStat(){
		Power.Clear ();
		foreach (stat y in System.Enum.GetValues(typeof(stat))) {
			Power.Add (y, 0);
		}
		Wearable x = new Wearable ();
		foreach(itemtype i in characterinfo.inUse.Keys){
			x = inUse [i];

			foreach (stat y in System.Enum.GetValues(typeof(stat))) {
				Power [y] += x.getPower (y);
			}
		}
	}

	public static bool TakeOut(itemtype itm ,int slt ){
		if (inUse.ContainsKey(itm)) {
			Wearable tmp = new Wearable ();

			// -1 : item üzerinden yok et alanına geldi demek
			if (slt == -1) {
				inUse [itm].Destroyitem ();
				inUse.Remove (itm);
				CalculateStat ();
				return true;
			}

			if (slt >= 0) {

				if (wearableinventory [slt] == null) {
					wearableinventory [slt] = inUse [itm];
					inUse.Remove (itm);
					CalculateStat ();
					return true;
				} else {
					tmp = inUse[itm];

					if (tmp.Type == wearableinventory [slt].Type) {
						inUse [itm] = wearableinventory [slt];
						wearableinventory [slt] = tmp;
						CalculateStat ();
						return true;
					} else {
						return false;
					}

				}

			}

		}
		return false;
	}

	public static string ViewStat(){
		string res = Name + "\n";
		foreach (stat x in Power.Keys) {
			res += x + " : " + Power [x] + "\n";
		}
		return res;
	}

	public static void destroy(int code){

		if (code < 15) {
			wearableinventory [code].Destroyitem ();
			wearableinventory [code] = null;
		} else {
			
		}

		switch (code) {
		case 15:
			inUse [itemtype.UpArmor].Destroyitem ();
			inUse.Remove (itemtype.UpArmor);
			break;
		case 16:
			inUse [itemtype.MiddleArmor].Destroyitem ();
			inUse.Remove (itemtype.MiddleArmor);
			break;
		case 17:
			inUse [itemtype.DownArmor].Destroyitem ();
			inUse.Remove (itemtype.DownArmor);
			break;
		case 18:
			inUse [itemtype.Wepon].Destroyitem ();
			inUse.Remove (itemtype.Wepon);
			break;
		}
		characterinfo.CalculateStat ();

	}

}
