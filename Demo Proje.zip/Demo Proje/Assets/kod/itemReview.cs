﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class itemReview : MonoBehaviour {

	public Dropdown[] opt = new Dropdown[5];
	datatype mod;
	public static Wearable Createitem = new Wearable();

	public InputField NameField;
	public InputField StatField;

	public Text datfield;

	public Sprite[] itemimages;
	public Image menimg;

	void Start () {
	}

	public void valChange(){
		ReLoadP1 ();
		Reimage ();
	}

	void Reimage(){
		switch (Createitem.Type) {

		case itemtype.UpArmor:
			menimg.sprite = itemimages [0];
			Createitem.Image = itemimages [0];
			break;
		case itemtype.MiddleArmor:
			menimg.sprite = itemimages [1];
			Createitem.Image = itemimages [1];
			break;
		case itemtype.DownArmor:
			menimg.sprite = itemimages [2];
			Createitem.Image = itemimages [2];
			break;
		case itemtype.Wepon:
			menimg.sprite = itemimages [3];
			Createitem.Image = itemimages [3];
			break;
		}

	}

	void ReLoadP1(){
		Createitem.Name = NameField.text;
		Createitem.Type = (itemtype)opt[0].value;
		Createitem.Disench = (disenchant)opt[1].value;
		Createitem.Update = (opt [2].value == 0) ? true : false;
		Createitem.Rank = (rarity)opt[3].value;
		PrintStat ();
	}

	public void addStat(){
		int sttval = 0;
		if (int.TryParse (StatField.text,out sttval)) {
			Createitem.setPower ((stat)opt [4].value, sttval);
		}
		PrintStat ();
	}

	public void Crtitem(){
		
	}

	public void PrintStat(){
		datfield.text = Createitem.inspect ();
	}
	

}
