﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class HidePopup : MonoBehaviour {

	const int viewTime = 3;

	public void ClosePopup(){
		StartCoroutine (closePopup ());
	}

	IEnumerator closePopup(){
		yield return new WaitForSeconds (viewTime);
		GetComponent<Text> ().text = "";
	}
}
