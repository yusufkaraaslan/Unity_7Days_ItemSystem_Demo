﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class changeMod : MonoBehaviour {

	public GameObject createPanel;
	public GameObject item;
	public GameObject inGameitem;
	public GameObject CharacterStat;

	bool masterMod = true;

	// Use this for initialization
	void Start () {
		createPanel = GameObject.FindGameObjectWithTag ("CreatePanel").gameObject;
		item = GameObject.FindGameObjectWithTag ("item").gameObject;
		inGameitem = GameObject.FindGameObjectWithTag ("inGameitems");
		CharacterStat = GameObject.FindGameObjectWithTag ("CharacterStat").gameObject;
		DrawItem.refresh = true;

		mod ();
	}
	
	public void mod(){
		if (masterMod) {
			createPanel.SetActive (true);
			item.SetActive (true);
			inGameitem.SetActive (false);
			CharacterStat.SetActive (false);
			masterMod = false;
		} else {

			GameObject.FindGameObjectWithTag ("UIManeger").GetComponent<DrawItem> ().drowItem ();
			createPanel.SetActive (false);
			item.SetActive (false);
			inGameitem.SetActive (true);
			CharacterStat.SetActive (true);
			masterMod = true;
		}
	}
}
