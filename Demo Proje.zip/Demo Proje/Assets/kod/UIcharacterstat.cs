﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class UIcharacterstat : MonoBehaviour {

	public Text StatView;

	public void PrintStat(){
		StatView.text = characterinfo.ViewStat ();
	}

	void Update(){
		PrintStat ();
	}

}
