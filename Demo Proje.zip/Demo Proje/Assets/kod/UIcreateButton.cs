﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class UIcreateButton : MonoBehaviour {

	public void UIcreate(){
		Wearable tmp = itemReview.Createitem.CloneItm();
		tmp.Lockitem ();
		characterinfo.Addinventory (tmp);
	}
}
